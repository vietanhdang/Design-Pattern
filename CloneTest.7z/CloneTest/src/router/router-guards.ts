import { isNavigationFailure } from 'vue-router';
import type { Router, RouteLocationNormalized } from 'vue-router';
import Storage from '../utils/Storage';
import { to as _to } from '@/utils/awaitTo';
import { useUserStore } from '@/store/modules/user';
import CommonFunction from '@/utils/CommonFunction';

const defaultRoutePath = '/';

export function createRouterGuards(router: Router, whiteNameList) {
    router.beforeEach(async (to, _, next) => {
        const token = CommonFunction.getToken();
        if (token) {
            if (to.name === 'Login') {
                next({ path: defaultRoutePath });
            } else {
                const [err] = await _to(useUserStore().afterLogin(token));
                if (err) {
                    useUserStore().resetToken();
                    return next({ name: 'Login', query: { redirect: to.fullPath }, replace: true });
                }
                const hasRoute = router.hasRoute(to.name!);
                if (!hasRoute) {
                    // If the route does not exist, it might be a dynamically registered route that is not ready yet,
                    // so redirect to the route again.
                    next({ ...to, replace: true });
                } else {
                    next();
                }
            }
        } else {
            if (whiteNameList.some((n) => n === to.name)) {
                next();
            } else {
                next({ name: 'Login', query: { redirect: to.fullPath }, replace: true });
            }
        }
    });

    // Get the name of the component associated with the route
    const getComponentName = (route: RouteLocationNormalized) => {
        const comp = route.matched.at(-1)?.components?.default;
        return comp?.name ?? (comp as any)?.type?.name;
    };

    router.afterEach((to, from, failure) => {
        const token = CommonFunction.getToken();
        if (isNavigationFailure(failure)) {
            const componentName = getComponentName(to);
            console.log(
                `Failed to navigate to ${to.fullPath} from ${from.fullPath} due to ${failure}`,
                componentName,
            );
        }

        if (!token) {
            useUserStore().resetToken();
        }
    });

    router.onError((error) => {
        console.log(error, 'Router error');
    });
}
