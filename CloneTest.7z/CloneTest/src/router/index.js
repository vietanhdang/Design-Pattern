import { createRouter, createWebHistory } from 'vue-router';
import { createRouterGuards } from './router-guards';

const whiteNameList = ['Login'];

const routes = [
    {
        path: '/',
        name: 'Home',
        component: () => import(/* webpackChunkName: "Home" */ '@/views/Home.vue'),
    },
    {
        path: '/Login',
        name: 'Login',
        component: () => import(/* webpackChunkName: "Login" */ '@/views/Login.vue'),
    },
    // 404 page must be placed at the end !!!
    {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: () => import('@/views/404.vue'),
    },
];

export const router = createRouter({
    history: createWebHistory(),
    routes,
});

// reset router
export function resetRouter() {
    router.getRoutes().forEach((route) => {
        const { name } = route;
        if (name && !whiteNameList.some((n) => n === name)) {
            router.hasRoute(name) && router.removeRoute(name);
        }
    });
}

export async function setupRouter(app) {
    // Configure routing guard
    createRouterGuards(router, whiteNameList);

    app.use(router);

    // Dynamic routing
    await router.isReady();
}
export default router;
