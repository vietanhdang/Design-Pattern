/**
 * plugins/index.js
 *
 * Automatically included in `./src/main.js`
 */

// Plugins
import vuetify from './vuetify';
import JsonViewer from 'vue3-json-viewer';
import 'vue3-json-viewer/dist/index.css';

export function registerPlugins(app) {
    app.use(vuetify);
    app.use(JsonViewer);
}
