import { defineStore } from 'pinia';
import Storage from '@/utils/Storage';
import CommonFunction from '@/utils/CommonFunction';
import GithubApi from '@/services/GithubApi';
import { store } from '@/store';

export const useUserStore = defineStore({
    id: 'user',
    state: () => ({
        token: CommonFunction.getToken(),
        userInfo: null,
        rateLimit: null,
    }),
    getters: {
        getToken() {
            return this.token;
        },

        getUserInfo() {
            return this.userInfo;
        },

        getRateLimit() {
            return this.rateLimit;
        },
    },
    actions: {
        resetToken() {
            this.userInfo = null;
            this.token = null;
            Storage.Cache.clear();
        },

        setToken(token) {
            this.token = token;
            CommonFunction.setToken(token);
        },

        async login(token) {
            try {
                const response = await GithubApi.getCurrentUser(token);
                if (response.status === 401) {
                    return Promise.reject('Invalid token');
                }
                return this.afterLogin(token, response.data);
            } catch (error) {
                return Promise.reject(error);
            }
        },

        async resetRateLimit() {
            const rateLimit = await GithubApi.getOctokit().rest.rateLimit.get();
            this.rateLimit = rateLimit.data;
        },

        /** Hàm này sẽ được gọi sau khi login thành công */
        async afterLogin(token, userInfo) {
            try {
                if (token) {
                    this.setToken(token);
                }
                if (userInfo) {
                    this.userInfo = userInfo;
                    CommonFunction.setUserInfoCache(userInfo);
                }

                await this.resetRateLimit();

                if (token && userInfo) {
                    return userInfo;
                }

                const userCache = CommonFunction.getUserInfo();
                if (userCache) {
                    this.userInfo = userCache;
                    return userCache;
                }

                userInfo = await GithubApi.getCurrentUser(token);
                this.userInfo = userInfo.data;
                CommonFunction.setUserInfoCache(userInfo.data);
                return Promise.resolve(userInfo.data);
            } catch (error) {
                return Promise.reject(error);
            }
        },

        /** Hàm này sẽ được gọi để logout */
        async logout() {
            this.resetToken();
        },
    },
});

export function useUserStoreWithOut() {
    return useUserStore(store);
}
