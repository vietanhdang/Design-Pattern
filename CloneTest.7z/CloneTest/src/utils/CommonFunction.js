import Storage from '@/utils/Storage';
import dayjs from 'dayjs';
import { openModal } from 'jenesius-vue-modal';
import { useUserStore } from '@/store/modules/user';

export default new (class CommonFunction {
    /**
     * @description: Mã hóa chuỗi thành base64
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    encodeBase64(str) {
        return btoa(unescape(encodeURIComponent(str)));
    }

    /**
     * @description: Giải mã chuỗi từ base64
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    decodeBase64(str) {
        return decodeURIComponent(escape(atob(str)));
    }

    /**
     * @description: Lấy token từ local storage
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    getToken() {
        const token = Storage.Cache.get('github_token');
        return token ? this.decodeBase64(token) : null;
    }

    /**
     * @description: Set token vào Local Storage
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    setToken(token) {
        Storage.Cache.set('github_token', this.encodeBase64(token));
    }

    /**
     * @description: Set thông tin user vào Local Storage
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    setUserInfoCache(userInfo) {
        Storage.Cache.set('github_user_info', this.encodeBase64(JSON.stringify(userInfo)));
    }

    /**
     * @description: Lấy thông tin user từ Local Storage
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    getUserInfo() {
        const userInfo = useUserStore().userInfo;
        return userInfo ?? Storage.Cache.get('github_user_info')
            ? JSON.parse(this.decodeBase64(Storage.Cache.get('github_user_info')))
            : null;
    }

    /**
     * @description: Convert UTC epoch seconds to date
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    convertEpochSecondsToDate(epochSeconds) {
        return dayjs.unix(epochSeconds).format('DD-MM-YYYY HH:mm:ss');
    }

    /**
     * @description: Show dialog view Json
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    async showDialog(data) {
        const { default: DialogViewJson } = await import('@/components/DialogViewJson.vue');
        const modal = await openModal(DialogViewJson, { data });
        modal.onclose = (event) => {};
    }
})();
