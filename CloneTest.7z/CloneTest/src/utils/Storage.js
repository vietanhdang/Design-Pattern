const DEFAULT_CACHE_TIME = 60 * 60 * 24 * 1000; // 1 day

const Cache = {
    prefix: '',
    storage: localStorage,

    getKey(key) {
        return `${this.prefix}${key}`.toUpperCase();
    },

    set(key, value, expire = DEFAULT_CACHE_TIME) {
        this.storage.setItem(
            this.getKey(key),
            JSON.stringify({
                value,
                expire: expire + Date.now(),
            }),
        );
    },

    get(key) {
        const item = this.storage.getItem(this.getKey(key));
        if (!item) return null;

        const data = JSON.parse(item);
        if (data.expire && data.expire < Date.now()) {
            this.remove(key);
            return null;
        }

        return data.value;
    },

    remove(key) {
        this.storage.removeItem(this.getKey(key));
    },

    expire(key) {
        if (this.get(key)) {
            this.remove(key);
        }
    },

    clear() {
        this.storage.clear();
    },
};

export default { Cache };
