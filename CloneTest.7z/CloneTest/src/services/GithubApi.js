import { Octokit } from 'octokit';
import Storage from '../utils/Storage';
import CommonFunction from '@/utils/CommonFunction';
import { useUserStore } from '@/store/modules/user';

export default new (class GithubApi {
    constructor() {}

    getOctokit() {
        const token = CommonFunction.getToken();
        const octokit = new Octokit({
            auth: token,
        });
        octokit.hook.wrap('request', async (request, options) => {
            const response = await request(options);
            if (response.status === 401) {
                useUserStore().resetToken();
                return Promise.reject('Invalid token');
            }
            if (response.headers['x-ratelimit-remaining'] && useUserStore().rateLimit !== null) {
                useUserStore().rateLimit['rate'] = {
                    remaining: response.headers['x-ratelimit-remaining'],
                    reset: response.headers['x-ratelimit-reset'],
                    used: response.headers['x-ratelimit-used'],
                    limit: response.headers['x-ratelimit-limit'],
                };
            }
            return response;
        });
        return octokit;
    }

    async request(options, cutomToken = null) {
        const token = cutomToken ?? CommonFunction.getToken();
        this.octokit = new Octokit({
            auth: token,
        });

        // Đảm bảo các tùy chọn hợp lệ và có phương thức
        if (!options || !options.method) {
            throw new Error('Invalid request options: must provide a method');
        }

        // Xây dựng URL và các tùy chọn cho Octokit.request
        const { method, url, headers, ...restOptions } = options;
        const requestOptions = {
            method: method || 'GET',
            url: this.buildUrl(url, options) || url,
            headers: {
                ...this.defaultHeaders,
                ...headers,
            },
            ...restOptions,
        };

        const response = await this.octokit.request(requestOptions);
        return response;
    }

    buildUrl(url, options) {
        // Nếu URL không chứa dấu ngoặc nhọn, trả về nguyên vẹn
        if (!url.includes('{')) {
            return url;
        }

        // Nếu URL chứa '{+path}', thêm các tùy chọn vào URL
        if (url.includes('{+path}') && options.path) {
            url.replace('{+path}', options.path);
        } else {
            url.replace('{+path}', '');
        }
        return url;
    }

    get defaultHeaders() {
        return {
            'x-github-api-version': '2022-11-28',
        };
    }

    async getCurrentUser(token) {
        return await this.getOctokit().request('GET /user');
    }

    /**
     * @description: Lấy thông tin các repo của user
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    async getAllRepositoryOfUser() {
        return await this.getOctokit().request('GET /users/repos');
    }

    /**
     * @description: Dynamic request
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    async dynamicRequest({ method, url, data, headers }) {
        return this.request({
            method,
            url,
            data,
            headers,
        });
    }
})();
