<template>
    <div class="header">
        <v-app-bar app color="grey-lighten-3" dark :elevation="1">
            <v-toolbar-title class="ml-4">Github API </v-toolbar-title>
            <v-menu v-if="userInfo" min-width="200px" rounded>
                <template v-slot:activator="{ props }">
                    <!-- Reset: {{ CommonFunction.convertEpochSecondsToDate(rateLimit.rate.reset) }} -->
                    <v-btn class="text-none" stacked>
                        <v-tooltip activator="parent" location="bottom">Rate Limit</v-tooltip>
                        <v-badge :content="rateLimit.rate.remaining" color="primary">
                            <v-icon>mdi-arrow-bottom-left-bold-box-outline</v-icon>
                        </v-badge>
                    </v-btn>
                    <v-btn class="text-none" stacked @click="resetRateLimit">
                        <v-tooltip activator="parent" location="bottom">Used</v-tooltip>
                        <v-badge :content="rateLimit.rate.used" color="primary">
                            <v-icon>mdi-database-arrow-up</v-icon>
                        </v-badge>
                    </v-btn>
                    <v-btn icon v-bind="props" size="small" @click="resetRateLimit">
                        <v-avatar size="small" color="brown">
                            <img :src="userInfo.avatar_url" width="48" />
                        </v-avatar>
                    </v-btn>
                </template>
                <v-card>
                    <v-card-text>
                        <div class="mx-auto text-center">
                            <p class="font-weight-bold">Hello: {{ userInfo.login }}</p>
                            <v-divider class="my-2"></v-divider>
                            <v-btn rounded variant="text" @click="logout" size="small">
                                Logout
                            </v-btn>
                        </div>
                    </v-card-text>
                </v-card>
            </v-menu>
        </v-app-bar>
    </div>
</template>

<script setup>
    import { useUserStore } from '@/store/modules/user';
    import { useRouter } from 'vue-router';
    import { computed } from 'vue';
    import CommonFunction from '@/utils/CommonFunction';
    // import { storeToRefs } from 'pinia'

    const userStore = useUserStore();
    // const  { userInfo } = storeToRefs(userStore);
    const router = useRouter();
    const userInfo = computed(() => userStore.userInfo);
    const rateLimit = computed(() => userStore.rateLimit);

    const resetRateLimit = () => {
        userStore.resetRateLimit();
    };

    const logout = () => {
        userStore.logout();
        router.push('/login');
    };
</script>

<style lang="scss" scoped></style>
