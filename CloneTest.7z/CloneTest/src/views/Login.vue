<script setup>
    import { ref } from 'vue';
    import { useUserStore } from '@/store/modules/user';
    import { useRouter, useRoute } from 'vue-router';

    const token = ref('');
    const loading = ref(false);
    const message = ref('');
    const route = useRoute();
    const router = useRouter();

    const login = async () => {
        try {
            loading.value = true;
            await useUserStore().login(token.value);
            // nếu có redirect thì chuyển hướng
            if (route.query.redirect) {
                router.push(route.query.redirect);
            } else {
                router.push('/');
            }
        } catch (error) {
            message.value = 'Invalid token';
        } finally {
            loading.value = false;
        }
    };
</script>

<template>
    <div class="h-100 d-flex justify-center align-center">
        <div class="">
            <v-card class="mx-auto px-6 py-8" max-width="344" width="344">
                <v-alert v-if="message" type="error" dismissible elevation="1" class="mx-auto mb-4">
                    {{ message }}
                </v-alert>
                <v-img
                    class="mx-auto"
                    src="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png"
                    max-height="100"
                    max-width="100"
                />
                <v-text-field v-model="token" label="Github Token" outlined dense class="mt-4" />
                <v-btn
                    @click="login"
                    color="primary"
                    class="w-100 mt-4"
                    variant="flat"
                    :loading="loading"
                    :disabled="loading"
                >
                    Login
                </v-btn>
                <v-card-text class="text-center mt-4">
                    <a
                        href="https://docs.github.com/en/github/authenticating-to-github/creating-a-personal-access-token"
                        target="_blank"
                        class="read-the-docs"
                    >
                        Read the docs
                    </a>
                </v-card-text>
            </v-card>
        </div>
    </div>
</template>

<style scoped>
    .read-the-docs {
        color: #888;
    }
</style>
