import { defineConfig } from 'vite';
import { fileURLToPath, URL } from 'url';
import pkg from './package.json';
import dayjs from 'dayjs';
import Components from 'unplugin-vue-components/vite';
import Vue from '@vitejs/plugin-vue';
import Vuetify, { transformAssetUrls } from 'vite-plugin-vuetify';
import ViteFonts from 'unplugin-fonts/vite';

const __APP_INFO__ = {
    pkg,
    lastBuildTime: dayjs().format('YYYY-MM-DD HH:mm:ss'),
};

export default defineConfig(({ command, mode }) => {
    return {
        plugins: [
            Vue({
                template: { transformAssetUrls },
            }),
            Vuetify(),
            Components(),
            ViteFonts({
                google: {
                    families: [
                        {
                            name: 'Roboto',
                            styles: 'wght@100;300;400;500;700;900',
                        },
                    ],
                },
            }),
        ],
        // server: {
        //     proxy: {
        //         '/api': {
        //             target: 'https://api.github.com',
        //             changeOrigin: true,
        //             rewrite: (path) => path.replace(/^\/api/, ''),
        //         },
        //     },
        // },
        define: {
            __APP_INFO__: JSON.stringify(__APP_INFO__),
        },
        resolve: {
            alias: [{ find: '@', replacement: fileURLToPath(new URL('./src', import.meta.url)) }],
            extensions: ['.js', '.json', '.jsx', '.mjs', '.ts', '.tsx', '.vue'],
        },
        server: {
            port: 3000,
        },
    };
});
