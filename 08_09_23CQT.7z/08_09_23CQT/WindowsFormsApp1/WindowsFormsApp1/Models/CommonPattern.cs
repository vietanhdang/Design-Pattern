﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
    public class CommonPattern
    {
        public static async Task<T> RetryOperationAsync<T>(Func<Task<T>> operation, int maxRetryCount = 10, int timeDelay = 50)
        {
            int retryCount = 0;

            while (retryCount < maxRetryCount)
            {
                try
                {
                    return await operation(); // Execute the operation
                }
                catch (Exception ex)
                {
                    if (ex is IBreakRetryException)
                    {
                        throw ex;
                    }
                    // Log the exception if needed
                    LogUtil.LogError($"Retry {retryCount + 1}: {ex.Message}");
                    retryCount++;

                    // Delay before retrying (optional)
                    await Task.Delay(timeDelay);
                }
            }

            // If all retries fail, throw an exception
            throw new Exception($"Operation failed after {maxRetryCount} retries.");
        }
    }

    public class AesEncryption
    {
        private const string IV = "t4G2MtDz/EcKR8CIcurZpQ==";
        private const int KeyLength = 32;

        private static byte[] KeyToBytes(string key) => Encoding.ASCII.GetBytes(key);

        private static string GetKey(string key)
        {
            while (key.Length < 32)
                key += key;
            return key.Substring(0, 32);
        }

        public static string Encrypt(string plainText, string key)
        {
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException(nameof(plainText));
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("Key");
            if ("t4G2MtDz/EcKR8CIcurZpQ==".Length <= 0)
                throw new ArgumentNullException("IV");
            byte[] array;
            using (Aes aes = Aes.Create())
            {
                aes.Key = AesEncryption.KeyToBytes(AesEncryption.GetKey(key));
                aes.IV = Convert.FromBase64String("t4G2MtDz/EcKR8CIcurZpQ==");
                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                            streamWriter.Write(plainText);
                        array = memoryStream.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(array);
        }

        public static string Decrypt(string base64Text, string key)
        {
            if (base64Text == null || base64Text.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("Key");
            byte[] buffer = Convert.FromBase64String(base64Text);
            using (Aes aes = Aes.Create())
            {
                aes.Key = AesEncryption.KeyToBytes(AesEncryption.GetKey(key));
                aes.IV = Convert.FromBase64String("t4G2MtDz/EcKR8CIcurZpQ==");
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                using (MemoryStream memoryStream = new MemoryStream(buffer))
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                            return streamReader.ReadToEnd();
                    }
                }
            }
        }
    }

}
