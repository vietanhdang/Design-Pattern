﻿using Newtonsoft.Json;
using Svg;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
    class MisaDecaptcha
    {
        private HttpClient _client { get; set; }
        public MisaDecaptcha()
        {
            _client = new HttpClient() { BaseAddress = new Uri("https://aiservice.misa.vn/v2/captcha-decode/") };
            _client.DefaultRequestHeaders.Add("x-api-key", "RDtZbUSo5yPYsOBmU4utkLDGH9p5qGFE");
            _client.DefaultRequestHeaders.Add("project", "misa-asp");
            _client.Timeout = TimeSpan.FromSeconds(10);
            _client.DefaultRequestHeaders.Add("User-Agent", RandomHeaderRequest.GetRandomUserAgent());
        }
        /// <summary>
        /// Lấy thông tin của các loại ảnh
        /// </summary>
        /// <param name="format" phần mở rộng của ảnh, .jpeg, jpg, png...</param>
        /// <returns></returns>
        public ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                {
                    return codec;
                }
            }
            return null;
        }

        /// <summary>
        /// Convert ảnh từ SVG sang JPEG dạng byte[]
        /// </summary>
        /// <param name="svgElement"></param>
        /// <returns></returns>
        public byte[] ConvertSvgToJpegByte(string svgElement)
        {
            SvgDocument svgDocument = SvgDocument.FromSvg<SvgDocument>(svgElement);
            using (var bitmap = svgDocument.Draw())
            {
                ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);
                Encoder myEncoder = Encoder.Quality;
                EncoderParameters myEncoderParameters = new EncoderParameters(1);
                EncoderParameter myEncoderParameter = new EncoderParameter(myEncoder, 100L);
                myEncoderParameters.Param[0] = myEncoderParameter;
                var whiteBackgroundBitmap = new Bitmap(bitmap.Width, bitmap.Height);
                using (var graphics = Graphics.FromImage(whiteBackgroundBitmap))
                {
                    graphics.FillRectangle(Brushes.White, 0, 0, bitmap.Width, bitmap.Height);
                    graphics.DrawImage(bitmap, 0, 0);
                }
                using (var ms = new MemoryStream())
                {
                    whiteBackgroundBitmap.Save(ms, jpgEncoder, myEncoderParameters);
                    return ms.ToArray();
                }
            }
        }

        /// <summary>
        /// Gọi sang bên dự án decaptcha để giải mã
        /// </summary>
        /// <param name="image byte">ảnh dạng byte[]</param>
        /// <returns></returns>
        public async Task<DeCaptchaResponse> DecodeCaptchaWithApi(byte[] imageByte)
        {
            using (var multipartFormContent = new MultipartFormDataContent())
            {
                using (var imageStream = new MemoryStream(imageByte))
                {
                    multipartFormContent.Add(new StreamContent(imageStream), name: "image", fileName: $"image_{DateTime.Now.Ticks}.jpg");
                    HttpResponseMessage response = await _client.PostAsync("image?vendor=hddtgov", multipartFormContent);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<DeCaptchaResponse>(responseBody);
                }
            }
        }
    }
}
