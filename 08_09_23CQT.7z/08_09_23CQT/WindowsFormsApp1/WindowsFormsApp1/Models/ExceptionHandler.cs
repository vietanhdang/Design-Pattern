﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
    public interface IBreakRetryException
    {
    }
   
    public class DownloadXMLException : Exception, IBreakRetryException
    {
        public DownloadXMLException(string message) : base(message)
        {
        }
    }
}
