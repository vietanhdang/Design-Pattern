﻿using Fleck;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {
        private HttpClient _client;

        public Form1()
        {
            InitializeComponent();
            _client = new HttpClient();
            // Thiết lập callback xác thực chứng chỉ máy chủ
            ServicePointManager.ServerCertificateValidationCallback = ValidateServerCertificate;

            // Khởi tạo và bắt đầu máy chủ WebSocket
            new WebSocketServer("ws://0.0.0.0:8148", false).Start((Action<IWebSocketConnection>)(socket =>
            {
                socket.OnOpen = () => Console.WriteLine("Open!");
                socket.OnClose = () => Console.WriteLine("Close!");
                socket.OnMessage = message =>
                {
                    //TODO: 
                };
                socket.OnError = ex =>
                {
                    socket.Send(JsonConvert.SerializeObject(new
                    {
                        Message = "Đồng bộ từ thuế lỗi",
                        IsBreak = true
                    }));
                };
            }));
        }

        private bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            // Viết mã xác thực chứng chỉ máy chủ ở đây
            // Trả về true nếu chứng chỉ hợp lệ, ngược lại trả về false
            // Ví dụ: 
            // return certificate.Subject.Contains("YourServerDomain.com");
            string expectedServerDomain = null;
            return string.IsNullOrEmpty(expectedServerDomain) ? true : certificate.Subject.Contains(expectedServerDomain);

        }

        /// <summary>
        /// Giá trị mặc định
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            //textBoxUsername.Text = "0107001729";
            //textBoxPassword.Text = "Tct@2023";
            textBoxUsername.Text = "5700496054";
            textBoxPassword.Text = "tKMI1aA@";
            //textBoxUsername.Text = "5701690431";
            //textBoxPassword.Text = "zKFb1aA@";
            // textBoxUsername.Text = "0310070374-004";
            // textBoxPassword.Text = "lbks1aA@";
            List<EInvoiceTab> tabs = new List<EInvoiceTab>();
            tabs.Add(new EInvoiceTab()
            {
                TabIndex = 0,
                TabName = "Hóa đơn điện tử bán ra"
            });
            tabs.Add(new EInvoiceTab()
            {
                TabIndex = 1,
                TabName = "Hóa đơn điện tử mua vào"
            });
            invoiceTypeCombobox.DataSource = tabs;
            invoiceTypeCombobox.DisplayMember = "TabName";
            invoiceTypeCombobox.ValueMember = "TabIndex";
            invoiceTypeCombobox.SelectedIndex = 0;
            // mặc định nếu không thay đổi combox tra cứu hóa đơn thì mặc định là hóa đơn điện tử mua vào
            InvoiceTypeCombobox_SelectedIndexChanged(null, null);
            // check thay đổi combox tra cứu hóa đơn
            invoiceTypeCombobox.SelectedIndexChanged += InvoiceTypeCombobox_SelectedIndexChanged;
            toDate.Value = DateTime.Now;
            fromDate.Value = DateTime.Now.AddDays(-30);
        }

        private void InvoiceTypeCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedTab = invoiceTypeCombobox.SelectedItem as EInvoiceTab;
            // hóa đơn điện tử mua vào
            List<InvoiceStatus> invoiceStatuses = new List<InvoiceStatus>();
            List<InvoiceCheckResult> invoiceCheckResults = new List<InvoiceCheckResult>();
            // hóa đơn điện tử mua vào
            // trạng thái hóa đơn
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 0,
                StatusName = "Tất cả"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 1,
                StatusName = "Hóa đơn mới"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 2,
                StatusName = "Hóa đơn thay thế"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 3,
                StatusName = "Hóa đơn điều chỉnh"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 4,
                StatusName = "Hóa đơn đã bị thay thế"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 5,
                StatusName = "Hóa đơn đã bị điều chỉnh"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 6,
                StatusName = "Hóa đơn đã bị hủy"
            });

            tthaiCombobox.DataSource = invoiceStatuses;
            tthaiCombobox.DisplayMember = "StatusName";
            tthaiCombobox.ValueMember = "Status";
            tthaiCombobox.SelectedIndex = 0;
            invoiceCheckResults.Add(new InvoiceCheckResult()
            {
                Result = -1,
                ResultName = "Tất cả"
            });

            if (selectedTab.TabIndex == 0)
            {
                // hóa đơn điện tử bán ra
                // 0: "Tổng cục Thuế đã nhận",
                // 1: "Đang tiến hành kiểm tra điều kiện cấp mã",
                // 2: "CQT từ chối hóa đơn theo từng lần phát sinh",
                // 3: "Hóa đơn đủ điều kiện cấp mã",
                // 4: "Hóa đơn không đủ điều kiện cấp mã",
                // 5: "Đã cấp mã hóa đơn",
                // 6: "Tổng cục thuế đã nhận không mã",
                // 7: "Đã kiểm tra định kỳ HĐĐT không có mã",
                // 8: "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 0,
                    ResultName = "Tổng cục Thuế đã nhận"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 1,
                    ResultName = "Đang tiến hành kiểm tra điều kiện cấp mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 2,
                    ResultName = "CQT từ chối hóa đơn theo từng lần phát sinh"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 3,
                    ResultName = "Hóa đơn đủ điều kiện cấp mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 4,
                    ResultName = "Hóa đơn không đủ điều kiện cấp mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 5,
                    ResultName = "Đã cấp mã hóa đơn"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 6,
                    ResultName = "Tổng cục thuế đã nhận không mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 7,
                    ResultName = "Đã kiểm tra định kỳ HĐĐT không có mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 8,
                    ResultName = "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                });
            }
            else
            {
                // 5: "Đã cấp mã hóa đơn",
                // 6: "Tổng cục thuế đã nhận không mã",
                // 8: "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 5,
                    ResultName = "Đã cấp mã hóa đơn"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 6,
                    ResultName = "Tổng cục thuế đã nhận không mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 8,
                    ResultName = "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                });

            }

            ttxlyCombobox.DataSource = invoiceCheckResults;
            ttxlyCombobox.DisplayMember = "ResultName";
            ttxlyCombobox.ValueMember = "Result";
            ttxlyCombobox.SelectedIndex = 0;
        }

        private void fromDate_ValueChanged(object sender, EventArgs e)
        {
            // lấy ngày cuối cùng của tháng
            DateTime lastDayOfMonth = new DateTime(fromDate.Value.Year, fromDate.Value.Month, DateTime.DaysInMonth(fromDate.Value.Year, fromDate.Value.Month));
            toDate.Value = lastDayOfMonth;
        }

        private async void btnGetInvoicesInRangeClick(object sender, EventArgs e)
        {
            //string taxCode = "5701690431";
            //string username = "5701690431";
            //string password = "zKFb1aA@";
            //0310070374-004
            //lbks1aA@

            button1.Enabled = false;
            InvoiceInfoRequest request = new InvoiceInfoRequest();
            request.StartDate = fromDate.Value;
            request.EndDate = toDate.Value;
            request.EinvoiceTab = (int)invoiceTypeCombobox.SelectedValue;
            request.InvoiceStatus = (int)tthaiCombobox.SelectedValue;
            request.InvoiceCheckResult = (int)ttxlyCombobox.SelectedValue;
            request.Unhiem = uynhiemCheckbox.Checked;

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            var crawler = new EInvoiceCrawler(textBoxUsername.Text, textBoxUsername.Text, textBoxPassword.Text);

            RequestSyncTaxAuthority requestSyncTax = new RequestSyncTaxAuthority
            {
                StartDate = fromDate.Value,
                EndDate = toDate.Value,
                IsSyncFromInputInvoice = (int)invoiceTypeCombobox.SelectedValue == 1,
                IsPaymentOrder = uynhiemCheckbox.Checked,
                OrganizationId = "646f13d9b30285c5f8a41b92",
                SubscriberId = "asp-c5a8fa968cb12ba97c68339e"
            };
            var frmDateString = fromDate.Value.ToString("dd/MM/yyyyT00:00:00", CultureInfo.InvariantCulture);
            var toDateString = toDate.Value.ToString("dd/MM/yyyyT23:59:59", CultureInfo.InvariantCulture);
            var textSearch = $"tdlap=ge={frmDateString};tdlap=le={toDateString}";
            

            //var invoiceListResult = await crawler.SyncInvoiceInRange(requestSyncTax);

            //lstInvoice.DataSource = null;
            //lstInvoice.DataSource = invoiceListResult;
            //totalRecord.Text = $"Total: {invoiceListResult.Count}";
            ////textInvoicesList.Text = JsonConvert.SerializeObject(lstInvoiceDownload);
            ////var lstInvoiceDetails = await crawler.GetInvoiceInfoAsyc(lstInvoiceDownload, progressBarManager);
            ////lstInvoice.DataSource = null;
            ////lstInvoice.DataSource = lstInvoiceDetails;
            ////var lstXmlByteAsync = await crawler.DownloadXmlAsync(lstInvoiceDownload, progressBarManager);
            //stopwatch.Stop();
            //double executionTimeInSeconds = (double)stopwatch.ElapsedMilliseconds / 1000;
            //timeExecute.Text = $"Execute time: {executionTimeInSeconds}s";
            //button1.Enabled = true;
            //await SendXmlToAnotherApiAsync(lstXmlByteAsync);
        }

        private void btnUploadInvoiceToASPClick(object sender, EventArgs e)
        {
            var crawler = new EInvoiceCrawler("", "", "");
            TaxaxionRequest request = new TaxaxionRequest();
            //request.MSTNBan = mstnb.Text; // 01070017290
            //request.Series = kh.Text; // "C23TAA";
            //request.InvoiceNo = sohoadon.Text; //"410";
            //request.TemplateNo = khmshd.Text; //"1";
            //var byteAsync = await crawler.DownloadXmlAsync(request);
            //await SendXmlToAnotherApiAsync(byteAsync);
        }

        private async Task SendXmlToAnotherApiAsync(List<byte[]> xmlData)
        {
            try
            {
                HttpClient _client = new HttpClient();
                string bearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJkNzc1MDIzMi1hYWVmLTQ0MjctOTAzMC1hYTcwNjc5ODMxOTAiLCJ1bmEiOiJkdmFuaDJAc29mdHdhcmUubWlzYS5jb20udm4iLCJhdXQiOiIyIiwidWVtIjoiZHZhbmgyQHNvZnR3YXJlLm1pc2EuY29tLnZuIiwiZm5hIjoiQW5oIMSQ4bq3bmcgVmnhu4d0IiwibG5hIjoiIiwibW9iIjoiIiwibmJmIjoxNjk1ODgzMDAzLCJleHAiOjE2OTU4OTc0MDMsImlhdCI6MTY5NTg4MzAwMywiaXNzIjoiTUlTQUpTQyJ9.ff5ZSUhsMQugBE2q685zSfNql5aRT7xmUk_ha9XhCio";
                var misaContext = new
                {
                    TenantId = "aadaf098-694e-4920-96d9-7c35a5c2d436",
                    TenantCode = "PI0LFKT4",
                    DatabaseId = "b2fadfa8-9690-4333-8276-7570571d6ce2",
                    BranchId = "c828c224-9475-43a1-b9a4-e0d59f640993",
                    WorkingBook = 0,
                    IncludeDependentBranch = false,
                    MainCurrency = "VND",
                    SessionId = "ssd7750232aaef44279030aa7067983190.8593c7e8-65f1-7d98-4207-2d1c1f05eb1d.b2fadfa89690433382767570571d6ce2.638315050034192615",
                    DBType = 2,
                    AuthType = 2,
                    HasAgent = true,
                    TaxCode = "5700496054",
                    UserType = 2,
                    Language = "vi"
                };

                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
                _client.DefaultRequestHeaders.Add("X-Misa-Context", JsonConvert.SerializeObject(misaContext));
                _client.DefaultRequestHeaders.Add("X-Misa-Branchid", "044a94ff-3e95-42df-933f-a6d221af1f68");
                string targetApiUrl = "https://actasp.misa.vn/g1/api/invoicebot/v1/invoice_bot/import_multi_inbot";
                using (var content = new MultipartFormDataContent())
                {
                    // Add form data fields
                    content.Add(new StringContent("0107001729"), "TaxCode");
                    content.Add(new StringContent("DVANH2"), "UserName");
                    content.Add(new StringContent("Tầng 9 - 18 Tam Trinh, Phường Minh Khai, Quận Hai Bà Trưng, Hà Nội"), "Address");

                    // Loop through the xmlData list and add each XML file to the request content
                    for (int i = 0; i < xmlData.Count; i++)
                    {
                        var xmlContent = new ByteArrayContent(xmlData[i]);
                        xmlContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                        content.Add(xmlContent, "files", "invoice_{i}.xml");
                    }

                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();

                    HttpResponseMessage response = await _client.PostAsync(targetApiUrl, content);
                    response.EnsureSuccessStatusCode();

                    // Handle the response from the target API as needed
                    string responseBody = await response.Content.ReadAsStringAsync();
                    stopwatch.Stop();
                    double executionTimeInSeconds = (double)stopwatch.ElapsedMilliseconds / 1000;
                    MessageBox.Show($"Total execution time sendToInbot: {executionTimeInSeconds}s");
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        private async void btnGetCaptchaClick(object sender, EventArgs e)
        {
            // tính toán thời gian thực hiện
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            var crawler = new EInvoiceCrawler(textBoxUsername.Text, textBoxUsername.Text, textBoxPassword.Text);
            var captcha = await crawler.GetCaptchaSvgFromWebsiteHDDT();
            MisaDecaptcha misaDecaptcha = new MisaDecaptcha();
            captchaKey.Text = captcha.Key;
            byte[] jpegBytes = misaDecaptcha.ConvertSvgToJpegByte(captcha.Content);
            using (MemoryStream memoryStream = new MemoryStream(jpegBytes))
            {
                Image captchaImage = Image.FromStream(memoryStream);
                captchaImageBox.Image = captchaImage;
            }
            btnGetCaptcha.Enabled = false;
            var decaptcha = await misaDecaptcha.DecodeCaptchaWithApi(jpegBytes);
            captchaText.Text = decaptcha.CaptchaText;
            btnGetCaptcha.Enabled = true;
            stopwatch.Stop();
            double executionTimeInSeconds = (double)stopwatch.ElapsedMilliseconds / 1000;
            MessageBox.Show($"Total execution time: {executionTimeInSeconds}s");
        }

        private void lstInvoice_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Make sure a valid row index is clicked
            {
                var selectedRow = lstInvoice.Rows[e.RowIndex];
                mstnb.Text = selectedRow.Cells["MSTNBan"].Value.ToString();
                kh.Text = selectedRow.Cells["Series"].Value.ToString();
                sohoadon.Text = selectedRow.Cells["InvoiceNo"].Value.ToString();
                khmshd.Text = selectedRow.Cells["TemplateNo"].Value.ToString();
            }
        }

        private async void btnCheckInvoiceStatus_Click(object sender, EventArgs e)
        {
            var invoiceListCheck = JsonConvert.DeserializeObject<List<TaxaxionRequest>>(textInvoicesList.Text);
            ProgressBarManager progressBarManager = new ProgressBarManager(progressBar); // Truyền ProgressBar vào constructor
            Stopwatch stopwatch = new Stopwatch();

            timer.Tick += (s, args) =>
            {
                string elapsedTimeString = string.Format("{0:00}:{1:00}:{2:00}.{3:000}",
                    stopwatch.Elapsed.Hours, stopwatch.Elapsed.Minutes, stopwatch.Elapsed.Seconds, stopwatch.Elapsed.Milliseconds);
                elapsedTimeLabel.Text = $"Thời gian chạy: {elapsedTimeString}";
            };
            timer.Start();
            stopwatch.Start(); // Bắt đầu đếm thời gian
            if (invoiceListCheck != null)
            {
                EInvoiceCrawler eInvoiceCrawler = new EInvoiceCrawler();
                var rs = await eInvoiceCrawler.GetInvoicesStatusAsync(invoiceListCheck, progressBarManager);
                if (rs != null)
                {
                    lstInvoiceStatus.DataSource = rs;
                    totalInvoiceStatus.Text = rs.Count.ToString();
                }
            }
            stopwatch.Stop(); // Dừng đếm thời gian
            timer.Stop();
            timeExecute.Text = elapsedTimeLabel.Text; // Xóa thông tin thời gian sau khi hoàn thành
            elapsedTimeLabel.Text = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var byteText = txtByte.Text;
            // dùng encoding utf-8 để convert từ byte sang string
            var text = Encoding.UTF8.GetBytes(byteText);
            File.WriteAllText("a.pdf", byteText);
        }
    }
}
