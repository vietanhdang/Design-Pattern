﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.fromDate = new System.Windows.Forms.DateTimePicker();
            this.toDate = new System.Windows.Forms.DateTimePicker();
            this.fromDateLabel = new System.Windows.Forms.Label();
            this.toDateLabel = new System.Windows.Forms.Label();
            this.mstnb = new System.Windows.Forms.TextBox();
            this.kh = new System.Windows.Forms.TextBox();
            this.sohoadon = new System.Windows.Forms.TextBox();
            this.khmshd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lstInvoice = new System.Windows.Forms.DataGridView();
            this.btnGetCaptcha = new System.Windows.Forms.Button();
            this.captchaKey = new System.Windows.Forms.TextBox();
            this.captchaText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.captchaImageBox = new System.Windows.Forms.PictureBox();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.labelUsername = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tthaiCombobox = new System.Windows.Forms.ComboBox();
            this.ttxlyCombobox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.uynhiemCheckbox = new System.Windows.Forms.CheckBox();
            this.invoiceTypeCombobox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.totalRecord = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.progressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.timeExecute = new System.Windows.Forms.ToolStripStatusLabel();
            this.textInvoicesList = new System.Windows.Forms.TextBox();
            this.btnCheckInvoiceStatus = new System.Windows.Forms.Button();
            this.lstInvoiceStatus = new System.Windows.Forms.DataGridView();
            this.totalInvoiceStatus = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.elapsedTimeLabel = new System.Windows.Forms.Label();
            this.txtByte = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.lstInvoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.captchaImageBox)).BeginInit();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lstInvoiceStatus)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(216, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 21);
            this.button1.TabIndex = 0;
            this.button1.Text = "Lấy hóa đơn";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnGetInvoicesInRangeClick);
            // 
            // fromDate
            // 
            this.fromDate.CustomFormat = "dd/MM/yyyy";
            this.fromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.fromDate.Location = new System.Drawing.Point(216, 30);
            this.fromDate.Name = "fromDate";
            this.fromDate.Size = new System.Drawing.Size(98, 20);
            this.fromDate.TabIndex = 1;
            this.fromDate.ValueChanged += new System.EventHandler(this.fromDate_ValueChanged);
            // 
            // toDate
            // 
            this.toDate.CustomFormat = "dd/MM/yyyy";
            this.toDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.toDate.Location = new System.Drawing.Point(320, 31);
            this.toDate.Name = "toDate";
            this.toDate.Size = new System.Drawing.Size(105, 20);
            this.toDate.TabIndex = 2;
            // 
            // fromDateLabel
            // 
            this.fromDateLabel.AutoSize = true;
            this.fromDateLabel.Location = new System.Drawing.Point(213, 14);
            this.fromDateLabel.Name = "fromDateLabel";
            this.fromDateLabel.Size = new System.Drawing.Size(46, 13);
            this.fromDateLabel.TabIndex = 3;
            this.fromDateLabel.Text = "Từ ngày";
            // 
            // toDateLabel
            // 
            this.toDateLabel.AutoSize = true;
            this.toDateLabel.Location = new System.Drawing.Point(317, 13);
            this.toDateLabel.Name = "toDateLabel";
            this.toDateLabel.Size = new System.Drawing.Size(53, 13);
            this.toDateLabel.TabIndex = 4;
            this.toDateLabel.Text = "Đến ngày";
            // 
            // mstnb
            // 
            this.mstnb.Location = new System.Drawing.Point(644, 14);
            this.mstnb.Name = "mstnb";
            this.mstnb.Size = new System.Drawing.Size(144, 20);
            this.mstnb.TabIndex = 6;
            // 
            // kh
            // 
            this.kh.Location = new System.Drawing.Point(644, 40);
            this.kh.Name = "kh";
            this.kh.Size = new System.Drawing.Size(144, 20);
            this.kh.TabIndex = 7;
            // 
            // sohoadon
            // 
            this.sohoadon.Location = new System.Drawing.Point(644, 66);
            this.sohoadon.Name = "sohoadon";
            this.sohoadon.Size = new System.Drawing.Size(144, 20);
            this.sohoadon.TabIndex = 8;
            // 
            // khmshd
            // 
            this.khmshd.Location = new System.Drawing.Point(644, 92);
            this.khmshd.Name = "khmshd";
            this.khmshd.Size = new System.Drawing.Size(144, 20);
            this.khmshd.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(563, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "MST NB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(563, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Ký hiệu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(563, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Số HĐ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(563, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "KH MSHĐ";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(644, 118);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "Tải hóa đơn";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnUploadInvoiceToASPClick);
            // 
            // lstInvoice
            // 
            this.lstInvoice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lstInvoice.Location = new System.Drawing.Point(18, 120);
            this.lstInvoice.Name = "lstInvoice";
            this.lstInvoice.Size = new System.Drawing.Size(532, 298);
            this.lstInvoice.TabIndex = 15;
            this.lstInvoice.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.lstInvoice_CellClick);
            // 
            // btnGetCaptcha
            // 
            this.btnGetCaptcha.Location = new System.Drawing.Point(916, 136);
            this.btnGetCaptcha.Name = "btnGetCaptcha";
            this.btnGetCaptcha.Size = new System.Drawing.Size(75, 23);
            this.btnGetCaptcha.TabIndex = 18;
            this.btnGetCaptcha.Text = "Lấy Captcha";
            this.btnGetCaptcha.UseVisualStyleBackColor = true;
            this.btnGetCaptcha.Click += new System.EventHandler(this.btnGetCaptchaClick);
            // 
            // captchaKey
            // 
            this.captchaKey.Location = new System.Drawing.Point(916, 69);
            this.captchaKey.Name = "captchaKey";
            this.captchaKey.Size = new System.Drawing.Size(144, 20);
            this.captchaKey.TabIndex = 19;
            // 
            // captchaText
            // 
            this.captchaText.Location = new System.Drawing.Point(916, 110);
            this.captchaText.Name = "captchaText";
            this.captchaText.Size = new System.Drawing.Size(144, 20);
            this.captchaText.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(835, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Captcha Key";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(835, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Captcha Text";
            // 
            // captchaImageBox
            // 
            this.captchaImageBox.Location = new System.Drawing.Point(838, 13);
            this.captchaImageBox.Name = "captchaImageBox";
            this.captchaImageBox.Size = new System.Drawing.Size(222, 50);
            this.captchaImageBox.TabIndex = 23;
            this.captchaImageBox.TabStop = false;
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.Location = new System.Drawing.Point(450, 31);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(100, 20);
            this.textBoxUsername.TabIndex = 24;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Location = new System.Drawing.Point(450, 73);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(100, 20);
            this.textBoxPassword.TabIndex = 25;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Location = new System.Drawing.Point(448, 14);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(55, 13);
            this.labelUsername.TabIndex = 26;
            this.labelUsername.Text = "Username";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(448, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "Password";
            // 
            // tthaiCombobox
            // 
            this.tthaiCombobox.FormattingEnabled = true;
            this.tthaiCombobox.Location = new System.Drawing.Point(18, 30);
            this.tthaiCombobox.Name = "tthaiCombobox";
            this.tthaiCombobox.Size = new System.Drawing.Size(192, 21);
            this.tthaiCombobox.TabIndex = 28;
            // 
            // ttxlyCombobox
            // 
            this.ttxlyCombobox.FormattingEnabled = true;
            this.ttxlyCombobox.Location = new System.Drawing.Point(18, 70);
            this.ttxlyCombobox.Name = "ttxlyCombobox";
            this.ttxlyCombobox.Size = new System.Drawing.Size(192, 21);
            this.ttxlyCombobox.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "Trạng thái hóa đơn";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "Kết quả kiểm tra";
            // 
            // uynhiemCheckbox
            // 
            this.uynhiemCheckbox.AutoSize = true;
            this.uynhiemCheckbox.Location = new System.Drawing.Point(19, 97);
            this.uynhiemCheckbox.Name = "uynhiemCheckbox";
            this.uynhiemCheckbox.Size = new System.Drawing.Size(113, 17);
            this.uynhiemCheckbox.TabIndex = 32;
            this.uynhiemCheckbox.Text = "Hóa đơn ủy nhiệm";
            this.uynhiemCheckbox.UseVisualStyleBackColor = true;
            // 
            // invoiceTypeCombobox
            // 
            this.invoiceTypeCombobox.FormattingEnabled = true;
            this.invoiceTypeCombobox.Location = new System.Drawing.Point(216, 70);
            this.invoiceTypeCombobox.Name = "invoiceTypeCombobox";
            this.invoiceTypeCombobox.Size = new System.Drawing.Size(209, 21);
            this.invoiceTypeCombobox.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(213, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "Tra cứu theo";
            // 
            // totalRecord
            // 
            this.totalRecord.AutoSize = true;
            this.totalRecord.Location = new System.Drawing.Point(356, 428);
            this.totalRecord.Name = "totalRecord";
            this.totalRecord.Size = new System.Drawing.Size(37, 13);
            this.totalRecord.TabIndex = 35;
            this.totalRecord.Text = "Total: ";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.progressBar,
            this.timeExecute});
            this.statusStrip1.Location = new System.Drawing.Point(0, 452);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1232, 22);
            this.statusStrip1.TabIndex = 37;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // progressBar
            // 
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(100, 16);
            // 
            // timeExecute
            // 
            this.timeExecute.Name = "timeExecute";
            this.timeExecute.Size = new System.Drawing.Size(78, 17);
            this.timeExecute.Text = "Execute time:";
            // 
            // textInvoicesList
            // 
            this.textInvoicesList.Location = new System.Drawing.Point(644, 147);
            this.textInvoicesList.Name = "textInvoicesList";
            this.textInvoicesList.Size = new System.Drawing.Size(144, 20);
            this.textInvoicesList.TabIndex = 38;
            // 
            // btnCheckInvoiceStatus
            // 
            this.btnCheckInvoiceStatus.Location = new System.Drawing.Point(644, 173);
            this.btnCheckInvoiceStatus.Name = "btnCheckInvoiceStatus";
            this.btnCheckInvoiceStatus.Size = new System.Drawing.Size(144, 23);
            this.btnCheckInvoiceStatus.TabIndex = 39;
            this.btnCheckInvoiceStatus.Text = "Kiểm tra trạng thái hóa đơn";
            this.btnCheckInvoiceStatus.UseVisualStyleBackColor = true;
            this.btnCheckInvoiceStatus.Click += new System.EventHandler(this.btnCheckInvoiceStatus_Click);
            // 
            // lstInvoiceStatus
            // 
            this.lstInvoiceStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lstInvoiceStatus.Location = new System.Drawing.Point(566, 213);
            this.lstInvoiceStatus.Name = "lstInvoiceStatus";
            this.lstInvoiceStatus.Size = new System.Drawing.Size(494, 205);
            this.lstInvoiceStatus.TabIndex = 40;
            // 
            // totalInvoiceStatus
            // 
            this.totalInvoiceStatus.AutoSize = true;
            this.totalInvoiceStatus.Location = new System.Drawing.Point(949, 427);
            this.totalInvoiceStatus.Name = "totalInvoiceStatus";
            this.totalInvoiceStatus.Size = new System.Drawing.Size(34, 13);
            this.totalInvoiceStatus.TabIndex = 41;
            this.totalInvoiceStatus.Text = "Total:";
            // 
            // elapsedTimeLabel
            // 
            this.elapsedTimeLabel.AutoSize = true;
            this.elapsedTimeLabel.Location = new System.Drawing.Point(794, 178);
            this.elapsedTimeLabel.Name = "elapsedTimeLabel";
            this.elapsedTimeLabel.Size = new System.Drawing.Size(77, 13);
            this.elapsedTimeLabel.TabIndex = 42;
            this.elapsedTimeLabel.Text = "Thời gian chạy";
            // 
            // txtByte
            // 
            this.txtByte.Location = new System.Drawing.Point(1082, 13);
            this.txtByte.Name = "txtByte";
            this.txtByte.Size = new System.Drawing.Size(138, 20);
            this.txtByte.TabIndex = 43;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1082, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 23);
            this.button3.TabIndex = 44;
            this.button3.Text = "Convert to PDF";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1232, 474);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.txtByte);
            this.Controls.Add(this.elapsedTimeLabel);
            this.Controls.Add(this.totalInvoiceStatus);
            this.Controls.Add(this.lstInvoiceStatus);
            this.Controls.Add(this.btnCheckInvoiceStatus);
            this.Controls.Add(this.textInvoicesList);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.totalRecord);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.invoiceTypeCombobox);
            this.Controls.Add(this.uynhiemCheckbox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ttxlyCombobox);
            this.Controls.Add(this.tthaiCombobox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelUsername);
            this.Controls.Add(this.textBoxPassword);
            this.Controls.Add(this.textBoxUsername);
            this.Controls.Add(this.captchaImageBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.captchaText);
            this.Controls.Add(this.captchaKey);
            this.Controls.Add(this.btnGetCaptcha);
            this.Controls.Add(this.lstInvoice);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.khmshd);
            this.Controls.Add(this.sohoadon);
            this.Controls.Add(this.kh);
            this.Controls.Add(this.mstnb);
            this.Controls.Add(this.toDateLabel);
            this.Controls.Add(this.fromDateLabel);
            this.Controls.Add(this.toDate);
            this.Controls.Add(this.fromDate);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lstInvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.captchaImageBox)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lstInvoiceStatus)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker fromDate;
        private System.Windows.Forms.DateTimePicker toDate;
        private System.Windows.Forms.Label fromDateLabel;
        private System.Windows.Forms.Label toDateLabel;
        private System.Windows.Forms.TextBox mstnb;
        private System.Windows.Forms.TextBox kh;
        private System.Windows.Forms.TextBox sohoadon;
        private System.Windows.Forms.TextBox khmshd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView lstInvoice;
        private System.Windows.Forms.Button btnGetCaptcha;
        private System.Windows.Forms.TextBox captchaKey;
        private System.Windows.Forms.TextBox captchaText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox captchaImageBox;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox tthaiCombobox;
        private System.Windows.Forms.ComboBox ttxlyCombobox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox uynhiemCheckbox;
        private System.Windows.Forms.ComboBox invoiceTypeCombobox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label totalRecord;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar progressBar;
        private System.Windows.Forms.ToolStripStatusLabel timeExecute;
        private System.Windows.Forms.TextBox textInvoicesList;
        private System.Windows.Forms.Button btnCheckInvoiceStatus;
        private System.Windows.Forms.DataGridView lstInvoiceStatus;
        private System.Windows.Forms.Label totalInvoiceStatus;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label elapsedTimeLabel;
        private System.Windows.Forms.TextBox txtByte;
        private System.Windows.Forms.Button button3;
    }
}

