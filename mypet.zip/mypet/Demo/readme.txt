- This file teaches you how to create your own screenmate on desktop.
- Please read this file before you edit "mypet.ini" setup file.
- You must follow the rules and instruction to edit "mypet.ini" setup file.
- "mypet.ini" contains 3 major sections :-
  [Setup] - Basic setup that are defined by application (thru. <Option> User Interface) to edit
  [Animation] - Basic graphical information about the screenmate, should fill in correctly by designer
  [Action] - Define all actions of the screenmate
- If you have make any error in "mypet.ini", program mypet.exe will prompt you where is the error.


Belows are the rules and format of the setup file "Mypet.ini" :

#
#	Mypet.ini setup file format
#

[Setup]
#
#  Mode = [0/1/2] (def : 1)
#          Display Mode :-
#          0 - Normal, require less resource 
#          1 - Better, require more memory (RAM) 
#          2 - Better, require faster CPU
#  Top Margin = [Top Margin Value] (def : 0)
#          Window top boundary for screenmate to display 
#  Bottom Margin = [Bottom Margin Value] (def : 0)
#          bottom margin measured from window bottom boundary
#  Left Margin = [left Margin Value] (def : 0)
#          Window left boundary for screenmate to display 
#  Right Margin = [Right Margin Value] (def : 0)
#          right margin measured from window right boundary
#  Timer = [Elapsed time in milliseconds] (def : 150)
#          Time-out value to display screenmate picture image


[Animation]
#  Application Name = [Name of Application] (def : My Pet)
#          * Application Name
#  Bitmap = [bitmap filename] (No default)     
#          * bitmap file for animation, this file must exist
#  Bitmap Mask = [Mono color bitmap mask filename] (def : Empty)     
#          * bitmap file in Mono color that is the transparent mask 
#            The bitmap format for this file MUST be in RGB color format
#            if it's missing, program will not support display mode 1 and 2 
#  Bitmap Title = [Title bitmap image for About Dialog Box] (def : Empty)
#          * if it's missing, no title will be displayed in About Dialog Box
#  Cursor = [Cursor filename] (No default)
#          * if missing, system default ARROW cursor will be used instead
#  Hold Cursor = [Cursor filename] (No default)
#          * Cursor image when pressing the left button of the mouse
#          * if missing, system default ARROW cursor will be used instead
#  Transparent Color = [Red, Green, Blue] (def : 0, 0, 0)
#          * the transparent color index used in bitmap file to indicate the 
#            transparent area of the bitmap image.
#            Range : 0->255, 0->255, 0->255
#  Num Of Image = [no. of image picture] (No default)          
#          * total no. of image of the animation
#  Num Of Action = [no. of actions defined] (No default)
#          * total no. of actions defined in animation
#  Image Height = [Image height in pixel] (No default)
#          * Image height in pixels
#  Image Width = [Image width in pixel] (No default)
#          * Image width in pixels
#  Start Action = [1st action no. when start] (def : 1)
#          * the 1st action that will be displayed when the screenmate 
#            program is started
#
#  Must satisfy the following rule, otherwise error message will display :
#    (Bitmap's width / Image Width) x (Bitmap's height / Image Height)
#     >= Num of Image
#

[Action]
#
#  action<1,..,No. of action> = <r><image?>, <image?>, ...
#
#          * this statement defines the image sequences for the specified 
#            action no.
#          * must have N lines if have defined N actions
#          * image no. must be in range (1 -> Num Of Image)
#          * if have "r" before the image no., this image is mirrored 
#          * e.g.   action1 = 1,2,r3,4,5
#            the image sequence for action No. 1 is :- Image No.1 and 
#            then 2, and then mirrored image 3, and then image 4 and 5.
#            
#  next<1,...,No. of action> = <r><action?>-<ratio>,
#                              <r><action?>-<ratio>, ...
#
#          * this statement defines the next possible action after this action
#            and its probability to occur
#          * must have N lines if have defined N actions
#          * action no. must be in range (1 -> Num Of Action)
#          * if have "r" before the action no., the action is mirrored
#          * ratio no. is the probability to occur for the next action in
#            percentage
#          * sum of ratio in this statement must be equal to 100
#          * e.g.   next1 = 1-30,2-40,r3-30
#            For action No. 1, the probabilities for the continuing actions
#            are :- 30% for action No.1, 40% for action No.2 and 30% for
#            action No.3 that is mirrored. 
#
#  x_step<1,...,No. of action> = <x step in pixel> (def : 0)
#
#          * this statement defines the step in horizontal direction
#          * if 0, no movement. If -ve., move to left, If +ve., move to right 
#          * e.g.   x_step1 = -10
#            For action No.1 the screenmate window will move to left with
#            10 pixels for every image frame.
#
#  x_bound<1,...,No. of action> = <r><action?>-<ratio>,
#                                 <r><action?>-<ratio>, ...
#
#          * this statement defines the next possible action and its 
#            probability to occur after hit the vertical screen boundary 
#          * same syntax with "next<?>" statement
#          * if have not defined "x_step<?>", this statement is meaningless
#          * if have defined "x_step<?>", but haven't define this statement,
#            action will be continued with no horizontal movement
#
#  y_step<1,...,No. of action> = <y step in pixel> (def : 0)
#
#          * this statement defines the step in vertical direction
#          * if 0, no movement. If -ve., move up, If +ve., move down
#
#  y_bound<1,...,No. of action> = <r><action?>-<ratio>,
#                                 <r><action?>-<ratio>, ...
#
#          * this statement defines the next possible action and its 
#            probability to occur after hit the horizontal screen boundary 
#          * same syntax with "next<?>" statement
#          * if have not defined "y_step<?>", this statement is meaningless
#          * if have defined "y_step<?>", but haven't define this statement,
#            action will be continued with no vertical movement
#
#  x_buffer<1,...,No. of action> = <pixel in horizontal direction> (def : 0)
#          
#          * this statement define the horizontal buffer for this 
#            action will be taken. If system find that the current 
#            position of the screenmate window have not had enough 
#            horizontal buffer, it will not select this action except
#            no other choice
#          * if 0, no buffer. If -ve., left buffer, If +ve., right buffer
#          * e.g. x_buffer1 = -20
#            For action No.1, it requires 20 pixels as left buffer. The
#            system will not prefer to select this action if the space 
#            between screenmate left boundary and the Window left margin is
#            smaller than the defined buffer size.
#
#  y_buffer<1,...,No. of action> = <pixel in vertical direction> (def : 0)
#          
#          * this statement define the vertical buffer for this 
#            action will be taken. If system find that the current 
#            position of the screenmate window have not had enough 
#            vertical buffer, it will not select this action except
#            no other choice
#          * if 0, no buffer. If -ve., upper buffer, If +ve., lower buffer
#
#  same_ratio<1,...,No. of action> = <factor to reduce the probability to repeat same action> (def : 0)
#
#          * this statement is used to reduce the probability to choose same action no.
#            for next selected action no.
#          * the larger the value, the probability to repeat the same action 
#            will be much more reduced.
#          * this value cannot be larger than the probability value of choosing same action
#          * if 0, the probability for the same repeated action will not be changed
#
#  dislike_action<1,...,No. of action> = <*|r><action dislike>-<factor to dislike>:<*|r><prev action in history>,
#                                        <*|r><action dislike>-<factor to dislike>:<*|r><prev action in history>,...
#    
#          * this statement used to avoid repeated action occurs. It will reduce the possibility
#            for some action.
#          * next action you want to reduce the probability to choose is defined 
#            by <action dislike>. Next action may have leading character "*" or "r". If the 
#            leading character is "r", the action you dislike is a mirrored action. If it is
#            "*", the action you dislikes include both its mirrored or non-mirrored action.
#          * <factor to dislike> is used to adjust the reduction of probability to choose
#            the dislike action. Larger the value, smaller probability to choose the dislike
#            action. 
#          * You can give one more condition to reduce the probability of next action.
#            Program will scan its action history list and will reduce the possibility of the
#            dislike action (action defined by <action dislike> if found that the history list
#            have contain action which its action no. is same to <prev. action in history>.
#            
#  
